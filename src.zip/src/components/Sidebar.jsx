import { Link } from "react-router-dom";

const Sidebar = () => {
  return (
    <div className="w-64 h-screen bg-gray-900 text-white p-5">
      <h2 className="text-xl font-bold mb-6">Expense Tracker</h2>
      <ul className="space-y-4">
        <li><Link to="/" className="block py-2 hover:bg-gray-700 rounded">🏠 Dashboard</Link></li>
        <li><Link to="/add-expense" className="block py-2 hover:bg-gray-700 rounded">➕ Add Expense</Link></li>
        <li><Link to="/settings" className="block py-2 hover:bg-gray-700 rounded">⚙️ Settings</Link></li>
        <li><Link to="/profile" className="block py-2 hover:bg-gray-700 rounded">👤 Profile</Link></li>
        <li><Link to="/contact" className="block py-2 hover:bg-gray-700 rounded">📞 Contact Us</Link></li>
      </ul>
    </div>
  );
};

export default Sidebar;
