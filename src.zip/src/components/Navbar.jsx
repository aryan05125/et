const Navbar = () => {
    return (
      <nav className="w-full bg-blue-600 text-white py-3 px-6 flex justify-between items-center">
        <h2 className="text-lg font-semibold">Dashboard</h2>
        <div className="flex items-center space-x-3">
          <img src="https://via.placeholder.com/40" alt="User" className="rounded-full w-10 h-10" />
          <span>Aryan</span>
        </div>
      </nav>
    );
  };
  
  export default Navbar;
  