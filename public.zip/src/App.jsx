import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";
import Dashboard from "./components/pages/Dashboard";
import AddExpense from "./components/pages/AddExpense";
import Settings from "./components/pages/Settings";
import Profile from "./components/pages/Profile";
import ContactUs from "./components/pages/ContactUs";

const App = () => {
  return (
    <Router>
      <div className="flex">
        <Sidebar />
        <div className="flex-1">
          <Navbar />
          <div className="p-6">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/add-expense" element={<AddExpense />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/contact" element={<ContactUs />} />
            </Routes>
          </div>
        </div>
      </div>
    </Router>
  );
};

export default App;